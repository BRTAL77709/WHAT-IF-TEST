"""Download only the pinned, checksum-verified free model if it is missing."""
from pathlib import Path
import hashlib,subprocess,json,sys
R=Path(__file__).resolve().parents[1]; (R/'models').mkdir(exist_ok=True)
files={'kokoro-v1.0.onnx':'beb0d1848dee9a49da392cc3df26958d46cfa35d321edf434f52949153f0df3a','voices-v1.0.bin':'bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d'}
for name,expected in files.items():
 p=R/'models'/name
 if not p.exists(): subprocess.run(['curl','-fLsS','-o',str(p),'https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/'+name],check=True)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,'Unverified model; do not synthesize'
 print('Verified',name)
